<?php

echo 123;
