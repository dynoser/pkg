<?php
namespace dynoser\webtools;

class Pkg {
    
}

echo 123;
